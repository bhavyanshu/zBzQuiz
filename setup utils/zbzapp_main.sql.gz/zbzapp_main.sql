-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 19, 2013 at 03:05 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zbzapp_main`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_test_status`
--

CREATE TABLE IF NOT EXISTS `course_test_status` (
  `testid` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `testname` varchar(65) NOT NULL,
  `testsubject` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `question_answer_choices`
--

CREATE TABLE IF NOT EXISTS `question_answer_choices` (
  `ansid` int(11) NOT NULL AUTO_INCREMENT,
  `quesid` int(11) NOT NULL,
  `choiceid` int(11) NOT NULL,
  `anstext` varchar(300) NOT NULL,
  `correct_answer` tinyint(1) NOT NULL,
  PRIMARY KEY (`ansid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `question_bank`
--

CREATE TABLE IF NOT EXISTS `question_bank` (
  `quesid` int(11) NOT NULL AUTO_INCREMENT,
  `testid` int(11) NOT NULL,
  `questext` varchar(500) NOT NULL,
  PRIMARY KEY (`quesid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `student_login_zbzxs`
--

CREATE TABLE IF NOT EXISTS `student_login_zbzxs` (
  `stuid` int(11) NOT NULL AUTO_INCREMENT,
  `stuname` varchar(65) NOT NULL,
  `stupass` varchar(100) NOT NULL,
  `stuemail` varchar(65) NOT NULL,
  `stulogintime` varchar(20) NOT NULL,
  `stulastlogouttime` varchar(20) NOT NULL,
  `stustatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`stuid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `student_login_zbzxs`
--

INSERT INTO `student_login_zbzxs` (`stuid`, `stuname`, `stupass`, `stuemail`, `stulogintime`, `stulastlogouttime`, `stustatus`) VALUES
(1, 'cryptstu', '$2y$11$yJmVFAe5fxG7wEoIcMqAJuWMFShSARnSalek2PT8Wuzl8MjlRbo1q', 'cryptstu@crypt.org', '28-07-2013 00:22:45', '14-07-2013 11:45:17', 1);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_course_status`
--

CREATE TABLE IF NOT EXISTS `teacher_course_status` (
  `courseid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `coursename` varchar(65) NOT NULL,
  `coursedesc` varchar(150) NOT NULL,
  PRIMARY KEY (`courseid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `teacher_course_status`
--

INSERT INTO `teacher_course_status` (`courseid`, `uid`, `coursename`, `coursedesc`) VALUES
(5, 4, 'Science', 'Science MCQ type questions for college students.'),
(6, 4, 'test2', 'test2 very long test of MCQs questions '),
(7, 4, 'test 3', 'test3 very long test of MCQs questions');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_login_zbzxt`
--

CREATE TABLE IF NOT EXISTS `teacher_login_zbzxt` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(65) NOT NULL,
  `upass` varchar(100) NOT NULL,
  `uemail` varchar(65) NOT NULL,
  `ulogintime` varchar(20) NOT NULL,
  `ulastlogouttime` varchar(20) NOT NULL,
  `ustatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `teacher_login_zbzxt`
--

INSERT INTO `teacher_login_zbzxt` (`uid`, `uname`, `upass`, `uemail`, `ulogintime`, `ulastlogouttime`, `ustatus`) VALUES
(1, 'admin', '48c753b8ba8cda41076ba122d1b9ef06', 'bhavyanshu.spl@gmail.com', '10-08-2013 11:33:19', '27-05-2013 19:11:12', 1),
(2, 'bhavyanshu', '1ef87566562385b2c1fead491286f47d', 'bhavyanshu.spl@gmail.com', '10-08-2013 11:33:19', '', 1),
(3, 'xyz', 'd16fb36f0911f878998c136191af705e', 'xyz@abc.com', '10-08-2013 11:33:19', '', 1),
(4, 'bcrypt', '$2y$11$3PsFmTtVzT7HFphzxoUYce67uXS3zqKOOJMRgnRr63bVj7afZb4jS', 'bcrypt@org.org', '10-08-2013 11:33:19', '10-08-2013 11:32:14', 1),
(5, 'uitest', '$2y$11$t1CFqiOBo9JRpiFxMXx64e9A655kd9bJneacbEiVz.YO9woGsQY26', 'uitest', '10-08-2013 11:33:19', '', 1),
(6, 'test2', '$2y$11$vSlhwIrA/AGP.EPggSVrHuafJbKuoC9iX73CNVicyZOh.yyWWrvfq', 'test2', '10-08-2013 11:33:19', '13-07-2013 22:58:18', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
